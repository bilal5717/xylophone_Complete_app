import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

void main(){
  return runApp(
    const Myapp(),
  );
}

class Myapp extends StatelessWidget {
  const Myapp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              displayButton(1 , Colors.purple),
              displayButton(2 , Colors.tealAccent),
              displayButton(3 , Colors.deepPurpleAccent),
              displayButton(4 , Colors.lime),
              displayButton(5 , Colors.lightBlueAccent),
              displayButton(6 , Colors.deepOrange),
              displayButton(7 , Colors.purpleAccent),
            ],
          ),
        ),
      ),
    );
  }
}

// a function to reduce repetition of same button code
Widget displayButton(int pos , Color color){
  return  Expanded(
    child: TextButton(
      style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all(color)
      ),
      onPressed: (){
        playSound(pos);
      }, child:const Text(''),

    ),
  );
}
// function to play a pressed button sound
void playSound(int target) {
  final player = AudioPlayer();
  player.play(UrlSource('assets/note$target.wav'));
}